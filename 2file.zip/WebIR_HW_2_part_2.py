'''
passi da seguire:

1) modificare l input dell algoritmo 1 per farlo lavorare nella matrice di teleporting o con prob uniforme(1) o con il topic(2)
2) dato lo user id fare il retrieve nel file (user_id,movie_id,rating) di tutte le righe che matchano con lo user_id e passarlo all algoritmo
3)quindi costruire un diz(movie_id:rating) già normalizzato
4)rilanciare il page rank con la teleporting modificata
5)nell output finale non considerare i movie per il quale lui ha votato
6)l output finale sono coppie movie_id page rank ordinato per page rank in modo decrescente
'''

import sys
import csv
import PageRank

input_graph_weighted_adjacency_list_file_name = sys.argv[1]
input_user_movie_rating=open(sys.argv[2],'r')
csv_reader_user_movie=csv.reader(input_user_movie_rating,delimiter='\t', quotechar='"',quoting=csv.QUOTE_NONE)
user_rating={}
user_id=int(sys.argv[3])
tot=0.0
for elem in csv_reader_user_movie:
	user_id_tmp=int(elem[0])
	if(user_id_tmp == user_id):
		rate=float(elem[2])
		tot+=rate
		user_rating[int(elem[1])]=rate
	elif(user_id_tmp > user_id):
		break
input_user_movie_rating.close()
		
if(user_rating != {}):
	for key in user_rating.keys():
		user_rating[key]/=tot
	
PageRank.main(input_graph_weighted_adjacency_list_file_name,2,user_rating)

		
		


